#ifndef CONFIG_H
#define CONFIG_H

// WiFi-configuratie
#define WIFI_SSID "devbit"
#define WIFI_PASSWORD "Dr@@dloos!"

#endif
