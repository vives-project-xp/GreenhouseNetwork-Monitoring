#ifndef CONFIG_H
#define CONFIG_H

// WiFi-configuratie
#define WIFI_SSID "jouw_wifi_ssid"
#define WIFI_PASSWORD "jouw_wifi_wachtwoord"

#endif
